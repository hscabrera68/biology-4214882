# GSE161967 analysis folder

This folder contains a standard bulk RNA-seq analysis script for GEO accession GSE161967, a dataset of longissimus dorsi muscle RNA-seq samples from Wagyu and Chinese Red Steppes cattle. The GEO record indicates 6 Bos taurus muscle RNA-seq samples, with 3 Wagyu and 3 Chinese Red Steppes, sequenced on Illumina HiSeq 2000 and hosted under GSE161967.

## Folder structure
- `code/analyze_GSE161967.py` - main Python script
- `results/` - output tables and plots generated after running the script
- `docs/` - optional notes

## What the script does
- Downloads GSE161967 metadata from GEO
- Downloads the supplemental FPKM matrix if available
- Builds sample metadata
- Performs log2(FPKM+1) transformation
- Generates QC plots
- Runs PCA
- Performs simple differential expression analysis using Welch t-tests
- Exports result tables and a volcano plot

## Install
```bash
pip install GEOparse pandas numpy scipy matplotlib seaborn scikit-learn openpyxl
```

## Run
```bash
python code/analyze_GSE161967.py
```

## Notes
This is a transparent "usual gene expression analysis" workflow for repository sharing and reviewer reproducibility. For publication-grade DE analysis, you may later replace the t-test block with limma-voom or DESeq2.
