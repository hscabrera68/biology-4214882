#!/usr/bin/env python3
import os
import numpy as np
import pandas as pd
import GEOparse
from scipy import stats
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
import seaborn as sns

OUTDIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'results')
os.makedirs(OUTDIR, exist_ok=True)


def download_gse161967():
    gse = GEOparse.get_GEO(geo='GSE161967', destdir='.', annotate_gpl=False)
    return gse


def download_fpkm_matrix(gse):
    supp = gse.metadata.get('supplementary_file', [])
    fpkm_url = None
    for url in supp:
        if 'GSE161967_All_FPKM.xlsx' in url:
            fpkm_url = url
            break
    if fpkm_url is None:
        raise RuntimeError('Could not find GSE161967_All_FPKM.xlsx URL in metadata')
    return pd.read_excel(fpkm_url, engine='openpyxl')


def build_sample_metadata(gse):
    rows = []
    for gsm_name, gsm in gse.gsms.items():
        title = gsm.metadata.get('title', [''])[0]
        if title.lower().startswith('wagyu'):
            group = 'Wagyu'
        elif 'chinese red steppes' in title.lower():
            group = 'ChineseRedSteppes'
        else:
            group = 'Unknown'
        rows.append({'gsm': gsm_name, 'title': title, 'group': group})
    return pd.DataFrame(rows).set_index('gsm')


def build_expression_matrix(fpkm_df, sample_meta):
    gene_col_candidates = [c for c in fpkm_df.columns if c.lower() in ['gene_id', 'geneid', 'gene', 'ensembl_id']]
    if not gene_col_candidates:
        raise RuntimeError('Cannot detect gene ID column in FPKM sheet')
    gene_col = gene_col_candidates[0]
    fpkm_df = fpkm_df.set_index(gene_col)
    col_map = {}
    for gsm, row in sample_meta.iterrows():
        title = row['title']
        if '[' in title and ']' in title:
            code = title.split('[')[-1].split(']')[0].strip()
        else:
            code = title
        match_cols = [c for c in fpkm_df.columns if code in str(c)]
        if len(match_cols) >= 1:
            col_map[gsm] = match_cols[0]
    if not col_map:
        raise RuntimeError('No sample columns could be mapped from FPKM to GSM IDs')
    expr = fpkm_df[list(col_map.values())].copy()
    expr.columns = list(col_map.keys())
    expr = expr.loc[(expr > 0).any(axis=1)]
    return expr


def log2_transform(expr):
    return np.log2(expr + 1.0)


def qc_plots(expr, sample_meta, prefix):
    lib_sizes = expr.sum(axis=0)
    plt.figure(figsize=(6, 4))
    sns.barplot(x=lib_sizes.index, y=lib_sizes.values, hue=sample_meta.loc[lib_sizes.index, 'group'])
    plt.xticks(rotation=45, ha='right')
    plt.ylabel('Total FPKM')
    plt.title('Library size per sample')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, f'{prefix}_library_size.png'), dpi=300)
    plt.close()

    plt.figure(figsize=(6, 4))
    for gsm in expr.columns:
        sns.kdeplot(expr[gsm], label=gsm, alpha=0.6)
    plt.xlabel('FPKM')
    plt.title('Expression distributions')
    plt.legend(fontsize=6)
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, f'{prefix}_density_raw.png'), dpi=300)
    plt.close()


def pca_plot(expr_log2, sample_meta, prefix):
    X = expr_log2.transpose()
    pca = PCA(n_components=2, random_state=0)
    pcs = pca.fit_transform(X)
    pc_df = pd.DataFrame(pcs, columns=['PC1', 'PC2'], index=X.index).join(sample_meta)
    plt.figure(figsize=(5, 4))
    sns.scatterplot(data=pc_df, x='PC1', y='PC2', hue='group', s=80, style='group')
    for gsm, row in pc_df.iterrows():
        plt.text(row['PC1'], row['PC2'], gsm, fontsize=7)
    plt.xlabel(f"PC1 ({pca.explained_variance_ratio_[0]*100:.1f}% var)")
    plt.ylabel(f"PC2 ({pca.explained_variance_ratio_[1]*100:.1f}% var)")
    plt.title('PCA: Wagyu vs Chinese Red Steppes')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, f'{prefix}_PCA.png'), dpi=300)
    plt.close()


def differential_expression(expr_log2, sample_meta):
    groups = sample_meta['group']
    wagyu = [gsm for gsm, g in groups.items() if g == 'Wagyu']
    crs = [gsm for gsm, g in groups.items() if g == 'ChineseRedSteppes']
    results = []
    for gene, row in expr_log2.iterrows():
        x = row[wagyu].values
        y = row[crs].values
        l2fc = x.mean() - y.mean()
        tstat, pval = stats.ttest_ind(x, y, equal_var=False)
        results.append({'gene': gene, 'log2FC_Wagyu_vs_CRS': l2fc, 't_stat': tstat, 'p_value': pval})
    de = pd.DataFrame(results).set_index('gene').sort_values('p_value')
    m = len(de)
    ranks = np.arange(1, m + 1)
    de['FDR_BH'] = (de['p_value'] * m / ranks).clip(upper=1.0)
    return de


def volcano_plot(de, prefix, fdr_thresh=0.05, l2fc_thresh=1.0):
    df = de.copy()
    df['neg_log10_p'] = -np.log10(df['p_value'] + 1e-300)
    df['sig'] = (df['FDR_BH'] < fdr_thresh) & (df['log2FC_Wagyu_vs_CRS'].abs() >= l2fc_thresh)
    plt.figure(figsize=(5, 4))
    sns.scatterplot(data=df, x='log2FC_Wagyu_vs_CRS', y='neg_log10_p', hue='sig', palette={True: 'red', False: 'grey'}, alpha=0.7, legend=False)
    plt.axhline(-np.log10(0.05), color='black', linestyle='--', linewidth=0.5)
    plt.axvline(l2fc_thresh, color='black', linestyle='--', linewidth=0.5)
    plt.axvline(-l2fc_thresh, color='black', linestyle='--', linewidth=0.5)
    plt.xlabel('log2FC (Wagyu vs CRS)')
    plt.ylabel('-log10(p-value)')
    plt.title('Volcano plot: GSE161967')
    plt.tight_layout()
    plt.savefig(os.path.join(OUTDIR, f'{prefix}_volcano.png'), dpi=300)
    plt.close()


def main():
    gse = download_gse161967()
    fpkm_df = download_fpkm_matrix(gse)
    sample_meta = build_sample_metadata(gse)
    sample_meta.to_csv(os.path.join(OUTDIR, 'GSE161967_sample_metadata.csv'))
    expr = build_expression_matrix(fpkm_df, sample_meta)
    expr.to_csv(os.path.join(OUTDIR, 'GSE161967_FPKM_matrix.csv'))
    qc_plots(expr, sample_meta, prefix='GSE161967')
    expr_log2 = log2_transform(expr)
    expr_log2.to_csv(os.path.join(OUTDIR, 'GSE161967_log2FPKM_matrix.csv'))
    pca_plot(expr_log2, sample_meta, prefix='GSE161967')
    de = differential_expression(expr_log2, sample_meta)
    de.to_csv(os.path.join(OUTDIR, 'GSE161967_DE_ttest_results.csv'))
    volcano_plot(de, prefix='GSE161967')
    sig = de[(de['FDR_BH'] < 0.05) & (de['log2FC_Wagyu_vs_CRS'].abs() >= 1.0)]
    sig.to_csv(os.path.join(OUTDIR, 'GSE161967_DE_top_genes.csv'))


if __name__ == '__main__':
    main()
