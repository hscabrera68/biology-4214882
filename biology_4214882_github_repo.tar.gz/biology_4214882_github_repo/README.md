# biology-4214882-marbling-model

GitHub-ready reproducibility repository for the manuscript:
**Biophysical Modeling Reveals How Gene Expression Drives Tissue-Scale Fat Deposition in Beef Breeds**

This repository combines:
1. Standard RNA-seq analysis code for GEO dataset **GSE161967**
2. CompuCell3D simulation code for tissue-scale marbling modeling
3. Configuration files and documentation for reproducibility

## Repository structure
- `code/rnaseq/analyze_GSE161967.py` — standard bulk RNA-seq workflow for GSE161967
- `code/cc3d/MarblingSteppables.py` — CompuCell3D steppables for fat progenitor seeding, adipogenic differentiation, and fat growth
- `config/wagyu_marbling.xml` — CompuCell3D XML model configuration
- `data/` — place processed data tables here
- `results/` — analysis outputs generated after running scripts
- `docs/` — documentation and manuscript-ready statements

## Data source
The transcriptomic dataset analyzed in this study is publicly available from NCBI GEO under accession **GSE161967**.

## Installation
### Python dependencies
```bash
pip install GEOparse pandas numpy scipy matplotlib seaborn scikit-learn openpyxl
```

### CompuCell3D
Install CompuCell3D separately from the official distribution appropriate for your operating system.

## Usage
### 1. RNA-seq analysis
```bash
python code/rnaseq/analyze_GSE161967.py
```
Outputs will be saved in `results/`.

### 2. CC3D simulation
Use `code/cc3d/MarblingSteppables.py` together with `config/wagyu_marbling.xml` in a CompuCell3D project.

## Suggested Data and Code Availability statement
The RNA-seq dataset analyzed in this study is publicly available in the NCBI Gene Expression Omnibus under accession number GSE161967. Processed data used to compute gene-module scores, φ and ψ values, and breed-level summary tables, together with all analysis scripts and CompuCell3D simulation files, are available in this public GitHub repository and will be archived on Zenodo upon release.

## DOI archiving
Recommended workflow:
1. Push this repository to GitHub as a public repo
2. Create a release (e.g., v1.0.0)
3. Connect GitHub to Zenodo
4. Archive the release on Zenodo to obtain a DOI
5. Update the manuscript statement with the GitHub URL and Zenodo DOI
