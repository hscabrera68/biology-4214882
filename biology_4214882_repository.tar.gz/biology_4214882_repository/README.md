# biology-4214882 reproducibility package

This folder is a starter package for depositing the code and data associated with the manuscript **"Biophysical Modeling Reveals How Gene Expression Drives Tissue-Scale Fat Deposition in Beef Breeds"**.

## Suggested repository structure
- `code/`: analysis scripts, parameter-mapping scripts, CompuCell3D steering scripts, notebooks
- `data/`: processed tables needed to reproduce figures and parameter values
- `docs/`: supplementary notes, environment details, figure-generation notes

## Included here
- `code/omics_to_params.py` (if available in the current workspace)
- `data/GSE161967_phi_psi_scores.csv` (if available in the current workspace)

## Recommended files to add before deposit
- CompuCell3D project files (`.cc3d`, XML, Python steering scripts)
- Figure-generation scripts
- Environment file (`requirements.txt` or `environment.yml`)
- License file
- Final README with run instructions

## Suggested README sections for your final repository
1. Overview
2. Repository contents
3. Data source (GSE161967)
4. Software requirements
5. How to reproduce parameter mapping
6. How to run CPM simulations
7. How to reproduce figures
8. License

## Deposit workflow
1. Create a GitHub repository and upload all files in this folder plus any missing simulation scripts.
2. Add a permissive license if allowed by your institution (for example, MIT for code).
3. Create a release on GitHub (for example, `v1.0.0-submission-revision`).
4. Connect the GitHub repository to Zenodo.
5. Archive the release in Zenodo to mint a DOI.
6. Add the DOI and repository URL to the manuscript's Data and Code Availability statement.
